package com.ndp.picodiploma.shoejima.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.ndp.picodiploma.shoejima.R

class CobaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_coba)
    }
}