# ShoejimaLaundry
Shoejima Laundry merupakan Sistem Informasi berbasis mobile yang dirancang menggunakan aplikasi Android Studio. Shoejima laundry merupakan aplikasi yang dibuat berdasarkan kemajuan teknologi yang bertujuan untuk mempermudah kegiatan masyarakat dalam proses pencucian sepatu. Di mana masyarakat yang dimaksud disini adalah mereka yang telah repot kerja seharian dan tidak memiliki waktu dan tenaga yang cukup untuk mencuci sepatu.

# Fitur-Fitur
- Pemesanan Laundry
- Details Pemesanan
- Pembayaran Laundry
- History Laundry

# Kontribusi Anggota
Pengembangan Front End  - 
                        - 

Pengembangan Back End   - 
                        - 
                        - 
                        


